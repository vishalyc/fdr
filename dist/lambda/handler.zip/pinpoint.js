"use strict";

// src/lambda/pinpoint.js
Object.defineProperty(exports, "__esModule", { value: true });
exports.getApplicationIdByName = getApplicationIdByName;
exports.getEndpoint = getEndpoint;
exports.updateOrCreateEndpoint = updateOrCreateEndpoint;
var AWS = require("aws-sdk");
var pinpoint = new AWS.Pinpoint({ region: "us-east-1" });
async function getApplicationIdByName(projectName) {
  const apps = await pinpoint.getApps({}).promise();
  if (!apps.ApplicationsResponse || !apps.ApplicationsResponse.Item) {
    throw new Error("No applications found or ApplicationsResponse is undefined");
  }
  const app = apps.ApplicationsResponse.Item.find((app2) => app2.Name === projectName);
  if (!app) {
    throw new Error(`Application with name ${projectName} not found`);
  }
  return app.Id;
}
async function getEndpoint(appId, endpointId) {
  try {
    const endpointResponse = await pinpoint.getEndpoint({
      ApplicationId: appId,
      EndpointId: endpointId
    }).promise();
    return endpointResponse.EndpointResponse;
  } catch (error) {
    if (error instanceof Error) {
      if (error.code === "NotFoundException") {
        return null;
      } else {
        throw error;
      }
    } else {
      throw new Error("An unknown error occurred");
    }
  }
}
async function updateOrCreateEndpoint(appId, endpointId, recipientId, recipientEmail, recipientName, vendorName, vendorId, attestationUrl, eventType) {
  const endpointRequest = {
    Address: recipientEmail,
    ChannelType: "EMAIL",
    Attributes: {
      recipientName: [recipientName],
      vendorName: [vendorName],
      vendorId: [vendorId],
      attestationUrl: [attestationUrl]
    },
    User: {
      UserId: recipientId,
      UserAttributes: {
        recipientName: [recipientName],
        vendorName: [vendorName]
      }
    }
  };
  if (eventType === "deleted") {
    endpointRequest.OptOut = "ALL";
  }
  const existingEndpoint = await getEndpoint(appId, endpointId);
  if (existingEndpoint) {
    await pinpoint.updateEndpoint({
      ApplicationId: appId,
      EndpointId: endpointId,
      EndpointRequest: endpointRequest
    }).promise();
    console.log(`Endpoint ${endpointId} updated.`);
  } else {
    await pinpoint.updateEndpoint({
      ApplicationId: appId,
      EndpointId: endpointId,
      EndpointRequest: endpointRequest
    }).promise();
    console.log(`Endpoint ${endpointId} created.`);
  }
}
