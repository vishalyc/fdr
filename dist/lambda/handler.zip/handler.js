"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/lambda/pinpoint.ts
var pinpoint_exports = {};
__export(pinpoint_exports, {
  getApplicationIdByName: () => getApplicationIdByName,
  getEndpoint: () => getEndpoint,
  updateOrCreateEndpoint: () => updateOrCreateEndpoint
});
async function getApplicationIdByName(projectName) {
  const apps = await pinpoint.getApps({}).promise();
  if (!apps.ApplicationsResponse || !apps.ApplicationsResponse.Item) {
    throw new Error("No applications found or ApplicationsResponse is undefined");
  }
  const app = apps.ApplicationsResponse.Item.find((app2) => app2.Name === projectName);
  if (!app) {
    throw new Error(`Application with name ${projectName} not found`);
  }
  return app.Id;
}
async function getEndpoint(appId, endpointId) {
  try {
    const endpointResponse = await pinpoint.getEndpoint({
      ApplicationId: appId,
      EndpointId: endpointId
    }).promise();
    return endpointResponse.EndpointResponse;
  } catch (error) {
    if (error instanceof Error) {
      if (error.code === "NotFoundException") {
        return null;
      } else {
        throw error;
      }
    } else {
      throw new Error("An unknown error occurred");
    }
  }
}
async function updateOrCreateEndpoint(appId, endpointId, recipientId, recipientEmail, recipientName, vendorName, vendorId, attestationUrl, eventType) {
  const endpointRequest = {
    Address: recipientEmail,
    ChannelType: "EMAIL",
    Attributes: {
      recipientName: [recipientName],
      vendorName: [vendorName],
      vendorId: [vendorId],
      attestationUrl: [attestationUrl]
    },
    User: {
      UserId: recipientId,
      UserAttributes: {
        recipientName: [recipientName],
        vendorName: [vendorName]
      }
    }
  };
  if (eventType === "deleted") {
    endpointRequest.OptOut = "ALL";
  }
  const existingEndpoint = await getEndpoint(appId, endpointId);
  if (existingEndpoint) {
    await pinpoint.updateEndpoint({
      ApplicationId: appId,
      EndpointId: endpointId,
      EndpointRequest: endpointRequest
    }).promise();
    console.log(`Endpoint ${endpointId} updated.`);
  } else {
    await pinpoint.updateEndpoint({
      ApplicationId: appId,
      EndpointId: endpointId,
      EndpointRequest: endpointRequest
    }).promise();
    console.log(`Endpoint ${endpointId} created.`);
  }
}
var AWS, pinpoint;
var init_pinpoint = __esm({
  "src/lambda/pinpoint.ts"() {
    "use strict";
    AWS = __toESM(require("aws-sdk"));
    pinpoint = new AWS.Pinpoint({ region: "us-east-1" });
  }
});

// src/lambda/handler.js
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var pinpoint_1 = (init_pinpoint(), __toCommonJS(pinpoint_exports));
var handler = async (event) => {
  try {
    for (const record of event.Records) {
      const body = JSON.parse(record.body);
      const projectName = "fdr";
      const recipientId = body.recipientId;
      const vendorId = body.vendorId;
      const endpointId = `${recipientId}-${vendorId}`;
      const eventType = body.type;
      const appId = await (0, pinpoint_1.getApplicationIdByName)(projectName);
      await (0, pinpoint_1.updateOrCreateEndpoint)(appId, endpointId, recipientId, body.recipientEmail, body.recipientName, body.vendorName, vendorId, body.attestationUrl, eventType);
    }
  } catch (error) {
    console.error("Error handling endpoint:", error);
    throw new Error(`Failed to process the message from SQS`);
  }
};
exports.handler = handler;
